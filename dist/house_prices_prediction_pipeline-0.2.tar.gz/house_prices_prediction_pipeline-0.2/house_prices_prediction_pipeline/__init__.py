FEATURES = ['price', 'area', 'bedrooms', 'bathrooms', 'stories',
            'mainroad', 'guestroom', 'basement', 'hotwaterheating',
            'airconditioning', 'parking', 'prefarea',
            'furnishingstatus']
CONTINIOUS_FEATURES = ['area', 'bedrooms']
CATEGORICAL_FEATURES = ['mainroad', 'furnishingstatus']
TARGET_FEATURE = 'price'
OUTPUT_DIR = '../models/'
